-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: trabalho
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `atributos`
--

DROP TABLE IF EXISTS `atributos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `atributos` (
  `id_atributo` int NOT NULL AUTO_INCREMENT,
  `drible` decimal(4,2) NOT NULL,
  `ritmo` decimal(4,2) NOT NULL,
  `fisico` decimal(4,2) NOT NULL,
  `passe` decimal(4,2) NOT NULL,
  `chute` decimal(4,2) NOT NULL,
  `defesa` decimal(4,2) NOT NULL,
  `geral` int NOT NULL DEFAULT '0',
  `id_jogador` int NOT NULL,
  PRIMARY KEY (`id_atributo`),
  KEY `id_jogador` (`id_jogador`),
  CONSTRAINT `atributos_ibfk_1` FOREIGN KEY (`id_jogador`) REFERENCES `jogadores` (`id_jogador`) ON DELETE CASCADE,
  CONSTRAINT `atributos_chk_1` CHECK ((`drible` between 0 and 100)),
  CONSTRAINT `atributos_chk_2` CHECK ((`ritmo` between 0 and 100)),
  CONSTRAINT `atributos_chk_3` CHECK ((`fisico` between 0 and 100)),
  CONSTRAINT `atributos_chk_4` CHECK ((`passe` between 0 and 100)),
  CONSTRAINT `atributos_chk_5` CHECK ((`chute` between 0 and 100)),
  CONSTRAINT `atributos_chk_6` CHECK ((`defesa` between 0 and 100)),
  CONSTRAINT `atributos_chk_7` CHECK ((`geral` between 0 and 100))
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atributos`
--

LOCK TABLES `atributos` WRITE;
/*!40000 ALTER TABLE `atributos` DISABLE KEYS */;
INSERT INTO `atributos` VALUES (1,90.00,82.00,73.00,80.00,86.00,44.00,88,1),(2,83.00,76.00,80.00,64.00,89.00,50.00,85,2),(3,67.00,92.00,78.00,51.00,83.00,90.00,85,3),(4,63.00,90.00,80.00,67.00,45.00,73.00,78,4),(5,80.00,72.00,83.00,77.00,70.00,74.00,83,5),(6,75.00,59.00,61.00,93.00,99.00,80.00,80,6),(7,59.00,45.00,80.00,72.00,61.00,84.00,83,7),(8,93.00,77.00,82.00,68.00,78.00,65.00,85,8),(9,89.00,89.00,89.00,89.00,89.00,89.00,96,9),(10,48.00,23.00,99.00,48.00,69.00,37.00,57,10),(11,78.00,78.00,78.00,78.00,78.00,78.00,84,11),(12,50.00,39.00,98.00,60.00,70.00,70.00,66,12),(13,71.00,80.00,84.00,73.00,82.00,80.00,84,13),(14,50.00,45.00,70.00,2.00,80.00,2.00,58,14),(15,0.00,99.00,0.00,0.00,99.00,0.00,41,15),(16,0.00,98.00,5.00,98.00,98.00,4.00,55,16),(17,86.00,80.00,72.00,81.00,86.00,36.00,87,17),(18,99.00,2.00,67.00,78.00,77.00,52.00,64,18);
/*!40000 ALTER TABLE `atributos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-03 16:41:34
