-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: trabalho
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `estilos_de_jogo_jogadores`
--

DROP TABLE IF EXISTS `estilos_de_jogo_jogadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estilos_de_jogo_jogadores` (
  `id_estilo` int NOT NULL,
  `id_jogador` int NOT NULL,
  PRIMARY KEY (`id_estilo`,`id_jogador`),
  KEY `id_jogador` (`id_jogador`),
  CONSTRAINT `estilos_de_jogo_jogadores_ibfk_1` FOREIGN KEY (`id_estilo`) REFERENCES `estilos_de_jogo` (`id_estilo`) ON DELETE CASCADE,
  CONSTRAINT `estilos_de_jogo_jogadores_ibfk_2` FOREIGN KEY (`id_jogador`) REFERENCES `jogadores` (`id_jogador`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estilos_de_jogo_jogadores`
--

LOCK TABLES `estilos_de_jogo_jogadores` WRITE;
/*!40000 ALTER TABLE `estilos_de_jogo_jogadores` DISABLE KEYS */;
INSERT INTO `estilos_de_jogo_jogadores` VALUES (1,1),(8,1),(16,1),(26,3),(32,3),(27,5),(10,6),(2,8),(12,8),(16,8),(18,8),(15,9),(2,10),(3,11),(14,13),(1,14),(14,14),(16,14),(25,14),(3,15),(24,15),(16,16),(18,16),(20,18);
/*!40000 ALTER TABLE `estilos_de_jogo_jogadores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-03 16:41:35
