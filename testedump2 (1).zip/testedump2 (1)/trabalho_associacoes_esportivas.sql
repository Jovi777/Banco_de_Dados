-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: trabalho
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `associacoes_esportivas`
--

DROP TABLE IF EXISTS `associacoes_esportivas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `associacoes_esportivas` (
  `id_associacao` int NOT NULL AUTO_INCREMENT,
  `sigla` varchar(3) NOT NULL,
  `apelido` varchar(20) DEFAULT NULL,
  `qualidade` decimal(3,2) DEFAULT NULL,
  `nome` varchar(45) NOT NULL,
  `mascote` varchar(20) DEFAULT NULL,
  `formacao` varchar(10) NOT NULL,
  `tipo` varchar(10) NOT NULL,
  PRIMARY KEY (`id_associacao`),
  CONSTRAINT `associacoes_esportivas_chk_1` CHECK ((`qualidade` between 0.0 and 5.00)),
  CONSTRAINT `associacoes_esportivas_chk_2` CHECK (((`tipo` = _utf8mb4'clube') or (`tipo` = _utf8mb4'selecao')))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `associacoes_esportivas`
--

LOCK TABLES `associacoes_esportivas` WRITE;
/*!40000 ALTER TABLE `associacoes_esportivas` DISABLE KEYS */;
INSERT INTO `associacoes_esportivas` VALUES (1,'PLV','Passe',4.50,'Passe Livre','Águia','4-4-2','selecao'),(2,'SKF','Knights',2.50,'Scarlet Knights','Cavaleiro','4-5-1','clube'),(3,'HLT','Peeks',4.50,'Hunslet','Hawk','4-2-3-1','clube'),(4,'WIN','Wanderers',4.50,'Winchester','Wanderer','4-5-1','clube'),(5,'CAM','C U Nited',3.00,'Cambridge United','','4-4-2','clube'),(6,'ZLT','Lions',4.00,'Zlatan Fc','Lion','5-2-2-1','clube'),(7,'CLT','Salariados',3.30,'Cltrabalho','Carteira','6-1-3','clube'),(8,'JEC','Jec',5.00,'Joinville','','5-4-1','clube'),(10,'BAG','Bagres',0.00,'Bagres Fc','Bagre','4-5-1','clube'),(11,'BAR','',4.20,'Bar Sem Lona','Caramelo','6-3','clube'),(12,'JUM','Jumentos',5.00,'Jumentus','Jegue','4-3-3','clube'),(13,'ING','',5.00,'Inglaterra','','4-3-3','selecao'),(14,'BRA','Canarinho',5.00,'Brasil','Canarinho','4-3-3','selecao'),(15,'ISL','Ice',2.00,'Islandia','Gelo','5-4-1','selecao'),(16,'SIN','Pura',1.00,'Singapura','Sin','6-1-3','selecao'),(17,'ALE','',5.00,'Alemanha','Aguia','4-3-2-1','selecao'),(18,'GRE','',4.00,'Grecia','','5-5-1','selecao'),(19,'FRA','',4.00,'Franca','','4-3-3','selecao'),(20,'ESP','',4.00,'Espanha','','4-5-1','selecao'),(21,'JOI','',1.00,'Joinville Rival','Garca','3-5-2','clube');
/*!40000 ALTER TABLE `associacoes_esportivas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-03 16:41:34
