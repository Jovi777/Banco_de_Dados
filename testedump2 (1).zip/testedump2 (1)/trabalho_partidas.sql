-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: trabalho
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `partidas`
--

DROP TABLE IF EXISTS `partidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partidas` (
  `id_partida` int NOT NULL AUTO_INCREMENT,
  `tempo` time DEFAULT NULL,
  `resultado` varchar(5) DEFAULT NULL,
  `id_campeonato` int DEFAULT NULL,
  `id_mandante` int DEFAULT NULL,
  `id_visitante` int DEFAULT NULL,
  PRIMARY KEY (`id_partida`),
  KEY `id_campeonato` (`id_campeonato`),
  KEY `id_mandante` (`id_mandante`),
  KEY `id_visitante` (`id_visitante`),
  CONSTRAINT `partidas_ibfk_1` FOREIGN KEY (`id_campeonato`) REFERENCES `campeonatos` (`id_campeonato`) ON DELETE CASCADE,
  CONSTRAINT `partidas_ibfk_2` FOREIGN KEY (`id_mandante`) REFERENCES `associacoes_esportivas` (`id_associacao`) ON DELETE CASCADE,
  CONSTRAINT `partidas_ibfk_3` FOREIGN KEY (`id_visitante`) REFERENCES `associacoes_esportivas` (`id_associacao`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partidas`
--

LOCK TABLES `partidas` WRITE;
/*!40000 ALTER TABLE `partidas` DISABLE KEYS */;
INSERT INTO `partidas` VALUES (1,'01:32:07','3-1',2,3,4),(2,'01:32:07','4-1',2,7,21),(3,'01:32:07','6-2',2,10,12),(4,'01:30:02','3-2',2,3,6),(5,'01:32:04','1-5',2,10,6),(6,'01:35:02','5-2',2,11,12),(7,'01:37:02','6-0',2,8,21),(8,'02:02:02','2-1',5,14,20),(9,'01:37:09','7-1',5,14,17),(10,'01:40:23','2-1',5,15,16),(11,'01:30:40','1-4',5,15,18),(12,'01:50:02','3-3',3,3,4),(13,'01:30:05','5-3',3,2,11),(14,'01:30:02','2-1',4,14,20),(15,'01:43:00','0-6',4,17,18),(16,'01:20:00','1-9',6,11,14),(17,'02:00:23','2-1',6,8,21);
/*!40000 ALTER TABLE `partidas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-03 16:41:33
